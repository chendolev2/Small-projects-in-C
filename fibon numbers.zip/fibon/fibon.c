#include <stdio.h>
#include <stdlib.h>

/* This program gets from the user a file name and a number (let's call it n),
 	creates Fibonacci series with n terms and prints all the elements 
 	in descending order to the requested file and the terminal itself */ 

#define MIN_FIB 0 /* Min number to create Fibonacci series */
#define MAX_FIB 46  /* Max number to create Fibonacci series */
#define MAX_CHAR 50 /* Longest possible input from user */
#define FILE_LOC 1 /* File's location in the argument's list */

typedef struct linked_list node;  /* uses "node" to define struct variables */
/* defines node in a circular linked list */
struct linked_list {
	int val;
	struct linked_list *next;
	};

/* create a circular linked list for storing the Fibonacci sequence. */
node* create_circular_list(int); 
/* Free the memory allocated for creating the Fibonacci sequence */
void free_memory(node *);
/* print terms of the Fibonacci sequence to the open file and the terminal */
void print_elements(FILE*, node*, int);
/* Calcualte the term num in the Fibonacci sequence */
unsigned long fib(int); 


/* Calcualte the term num in the Fibonacci sequence */
unsigned long fib(int num) 
{
	unsigned long a, b, result;
	int i;
	
    	if (num <= 1)
        		return num;
     	a = 0;  
    	b = 1;  
   	result = 0; /* sum of the last 2 elements */

    	for (i = 2; i <= num; i++)
    	{
        		result = a + b;
        		a = b;
        		b = result;
    	}

    	return result;
}

/* Prints all the terms of the Fibonacci sequence, in descending order, 
	to both the opened file (one of the parameters) and the terminal.*/
void print_elements(FILE *file, node *head, int n)
{
	node *head_ptr = head -> next; /* fib(n) */
         printf("The terms of the Fibonacci series up to Fib(%d) are:\n", n);
	fprintf(file, "The purpose of the program is to print all the " \
	"terms of the Fibonacci sequence in descending order up to "\
						"Fib(%d).\n\n", n);
	
	while (head_ptr != NULL && head_ptr -> next != head -> next)
	{
		printf("fib(%d) = %d\n", n, head_ptr -> val);
		fprintf(file, "fib(%d) = %d\n", n, head_ptr -> val);	
		n--; /* for the next loop, printing in descending order */ 
		head_ptr = head_ptr -> next;
	}
	/* prints the last element fib(0) */
	printf("fib(%d) = %d\n", n, head_ptr -> val);
	fprintf(file, "fib(%d) = %d\n", n, head_ptr -> val);
	
}

/* Free the memory allocated for creating the Fibonacci sequence - each term 
	is saved in a node structure and is released separately */
void free_memory(node *head)
{
	node *temp;
	node *current = head;
	while (current != NULL && current -> next != head)
	{
		temp = current;
		current = current -> next;
		free(temp);
	}
	free(current);
}

/* Creates a circular list, using linked list structure.
	Each term in the list is a term in the Fibonacci sequence.
	The function gets 2 parameters: 
	* n = number of terms in Fibonacci sequence. (how much to create)
	* head = a pointer to the first added term in the sequence */
node* create_circular_list(int n) 
{
	node *curr;
	node *tail = NULL;
	node *head = NULL;
	int i;

	/* adds nodes into the linked list */
	for (i = 0; i <= n; i++)
	{
		curr = (node *)malloc(sizeof(node)); /* creates space -node */
		if (curr == NULL) /* Allocation failed, can't continue */
		{
			printf("Allocation of node %d space failed. "\
					"The program stopped.\n", i);
			if (head != NULL)
				free_memory(head);
			return NULL;
		}
		curr -> val = fib(i); /* sets node's value */
		curr -> next = NULL;

		/* if the current node is the first node */
		if (head == NULL)
		{
			head = curr;
			tail = curr;
		}
		else /* need to link between the last 2 nodes */
		{
			curr -> next = tail;
			tail = curr;
		}
	} /* end of loop */
	
	/* link between the first node and the last node to create circle */
	head -> next = tail; 
	return head;
}		


int main(int argc, char* argv[])
{
	node *head; /*the first added node to the circular linked list*/
	FILE *file; /* for writing the Fibonacci series */
	int n = MIN_FIB-1; /* How many numbers to return in Fibonacci series */

	/* parameters validation */
	if (argc != 2)  /* validates there is only one parameter (file) */
	{
		printf("The number of parameters is not valid. " \
			"Can't run the program. \nPlease make sure there" \
			" is one valid file name after the runfile.\n");
		return 0;
	}
	/* Validates whether the given file can be opened. */
	if ((file = fopen(argv[FILE_LOC], "w")) == NULL) 
	{
		printf("Can't open the file %s. Please try again.\n", *argv);
		return 0;
	}
	
	/* asks number for fib function */
	printf("please enter a positive integer between %d and %d:\n", \
	 					MIN_FIB, MAX_FIB);
	/* checks number's validation */ 				
	if (scanf("%d", &n) != 1)
	{
		printf("You didn't type a number. Program stopped.\n");
		return 0;
	} 
	if (n < MIN_FIB || n > MAX_FIB) /* user's num out of requested range */
	{
		printf("The number you entered isn't in the range %d - %d." \
		" Program stopped.\n",MIN_FIB, MAX_FIB);
		return 0;
	}
	
	/* Creating a circular linked list */
	if ((head = create_circular_list(n)) != NULL)
	{	
		/* prints circular list's elements */
		print_elements(file, head, n);
		/* frees all allocated memory of the circular list */
		free_memory(head); 
	} 

	fclose(file);
	return 0;	
}	
		
