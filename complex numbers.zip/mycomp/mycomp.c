#include "complex.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "mycomp.h"

/* This file contains the main function. The program includes tests on the input
	 and calls to functions that perform operations on complex numbers. */

void message_for_user(void) 
{
	printf("Welcome!\nPlease enter commands you would like to operate" \
	"\nEach command should be with max %d characters\n" \
	"Below are the commands you can choose with examples:\n", MAX_LENGTH); 
	printf("\n1. Update: complex and 2 numbers. read_comp A, 5, 2.5\n" \
	"2. Print: with complex.  print_comp B\n" \
	"3. Add: 2 complex.  add_comp C, D\n" \
	"4. Subtract: 2 complex.  sub_comp B, C\n" \
	"5. Multiply: complex with real. mult_comp_real E, 5\n" \
	"6. Multiply: complex with imaginary. mult_comp_img D, 2.4\n" \
	"7. Multiply: complex with complex. mult_comp_comp F, A\n" \
	"8. Absolute value: complex.  abs_comp E\n" \
	"9. Stop: stop the program, must be at the end. stop\n");
	printf("\nPlease notice: \n" \
	"- Be sure to write correctly\n" \
	"- Use a space after the function name, "\
		 "separate parameters with a comma\n" \
	"- The available complex variables are: A,B,C,D,E,F\n" \
	"\nEnjoy!\n\n");
}


/* Checks if the current input is a single word without any space after the 
	first word */
int is_single_word(char* input)
{
    int i = 0;
    /* runs through all characters */
    while (input[i] != '\0' && !isspace((unsigned char)input[i]))
        i++;
      

    while (isspace((unsigned char)input[i])) /* runs through all spaces */
        i++;
	
	
    if (input[i] == '\0' || input[i] == '\n') /* checks last character */
        return 1;
  
    return 0;
}


/* Checks if the input equals one of the legal functions */
int input_equals_function(char* input)
{
	remove_all_spaces(input);
	if (strcmp(input, "read_comp") == 0 ||
	strcmp(input, "print_comp") == 0 ||
	strcmp(input, "add_comp") == 0 ||
	strcmp(input, "sub_comp") == 0 ||
	strcmp(input, "mult_comp_real") == 0 ||
	strcmp(input, "mult_comp_img") == 0 ||
	strcmp(input, "mult_comp_comp") == 0 ||
	strcmp(input, "abs_comp") == 0 ||
	strcmp(input, "stop") == 0)
	{
		return 1;
	}
	return 0;
}


/* checks if the last character in the input is a digit, letter or space,
 	return 1 for right answer, 0 otherwise */	
int last_char_alpha_float_space(char* input)
{
    int length = strlen(input);
    if (length > 0) 
    {
        char last_char = input[length - 1];
        if (isalpha(last_char) || isdigit(last_char) || last_char == ' ')
            return 1; /* Last character is a letter or digit */
    }
 
    return 0; 
}


/* removes leading and trailing spaces in user's input */
void remove_leading_trailing_spaces(char* input)
{
    int length = strlen(input);
    int start = 0;
    int end = length - 1;
    int i, j = 0;

    /* Finds the index of the first non space character */
    while (isspace(input[start]))
        start++;

    /* Finds the index of the last non space character */
    while (end >= start && isspace(input[end]))
        end--;

    /* Shifts the characters (leading spaces) */
    
    for (i = start; i <= end; i++)
        input[j++] = input[i];

    input[j] = '\0';
}


/* Gets the input the user typed and checks if the typed request is legal and 
	can be operated by the program. Prints error mistake if something is
	wrong. Returns 0 if the function is not valid,
	1 otherwise */
int is_input_valid(char* input, char* function, char* parameters[])
{
	/* Skips leading and trailing spaces */
    	remove_leading_trailing_spaces(input);

	if (is_single_word(input) == 1) 
	{
		strcpy(function, input);
		if (input_equals_function(input) == 0) /*not valid*/
		{
			printf("Error - Undefined function name\n");
			return 0;
		}
		else if (strcmp(input, "stop") == 0)
			return 1;
			
		else
		{
			
			printf("Error - At least one parameter is missing");
			return 0;
		}
	}

	if (is_valid_function(input, function) == 0)
	{
		printf("Error - Undefined function name\n");
		return 0;
	}
	remove_function(input); /* removes the function from the input */
	
    	remove_leading_trailing_spaces(input);

	if (input[0] == ',')
	{
		printf("Error - Illegal comma after function name\n");
		return 0;
	}	
	if (no_missing_commas(input) == 0) /* Is there a missing comma */
	{
		printf("Error - At least one comma is missing\n");
		return 0;
	}	
	remove_all_spaces(input);  /* removes all spaces from the input */
	if (no_consecutive_commas(input) == 0) /* No 2 commas in a row */
	{
		printf("Error - Multiple consecutive commas\n");
		return 0;
	}
	/* checks if last digit it's not digit, letter or space */
	if (last_char_alpha_float_space(input) == 0)
	{
		printf("Error - Illegal last character");
		return 0;
	}
	if (parameters_num_correct(input, parameters, function) == 0) 	
		return 0;
	return 1;	
}

/* Checks for the selected function if its number of parameters is equal to the
 	number of parameters entered by the user. Prints an error message and
 	returns 0 if there is no match, returns 1 otherwise */
int num_parmeters_match(char* function, int num_param)
{	
	char* message = "";
	char msg_missing[] = "Error - At least one parameter is missing";
	char msg_many[] = "Error - Too many parameters, extraneous text";

	if (strcmp(function,"read_comp") == 0 && num_param != READ_COMP)
		message = num_param < READ_COMP ? msg_missing: msg_many;
	else if (strcmp(function, "print_comp") ==0 && num_param != PRINT_COMP)
		message = num_param < PRINT_COMP ? msg_missing: msg_many;
	else if (strcmp(function, "add_comp") == 0 && num_param != ADD_COMP)
		message = num_param < ADD_COMP ? msg_missing: msg_many;
	else if (strcmp(function, "sub_comp") == 0 && num_param != SUB_COMP)
		message = num_param < SUB_COMP ? msg_missing: msg_many;
	else if (strcmp(function, "mult_comp_real") == 0 \
					&& num_param != MULT_COMP_REAL)
		message = num_param < MULT_COMP_REAL ? msg_missing: msg_many;
	else if (strcmp(function, "mult_comp_img") == 0 \
					 && num_param != MULT_COMP_IMG)
		message = num_param < MULT_COMP_IMG ? msg_missing: msg_many;
	else if (strcmp(function, "mult_comp_comp") == 0 \
					 && num_param != MULT_COMP_COMP)			
		message = num_param < MULT_COMP_COMP ? msg_missing: msg_many;
	else if (strcmp(function, "abs_comp") == 0 && num_param != ABS_COMP)
		message = num_param < ABS_COMP ? msg_missing: msg_many;	
	else if (strcmp(function, "stop") == 0 && num_param > STOP)
		message = msg_many;
	else
		message = "";
		
	if(strcmp(message, msg_missing) == 0 || strcmp(message, msg_many) == 0)
	{
		printf("%s", message);
		return 0;
	}
	return 1;
} 
			
	
/* Checks if the numbers of parameters the user typed matches the number of 
	parameters the chosen function gets. Returns 0 if there is a mismatch*/
int parameters_num_correct(char *input, char* parameters[], char* function)
{
	int i = 0, num_parameters = 0;
	char *token;
	narrow_spaces(input); /* leaves only one space */
	
	token = strtok(input, ","); 
		
	/* counts how many parameters user inserted */
	while (token != NULL) 
	{	if (i < PARAMETERS)
		{
			parameters[i] = token;
			i++;
		}
		num_parameters ++;
		token = strtok(NULL, ","); 	
	}
	
	if (num_parmeters_match(function, num_parameters) == 0)
		return 0; /* Parameters are missing or there are too many */
	/* exacly amount of parameters */
	
        	/* updates all the parametes that have no value to an empty string */
        	while (i < PARAMETERS)
        	{
        		parameters[i] = "";
        		i ++;
        	}
	return 1;
}


/* Checks that there are no two consecutive commas, returns 0 if consecutive 
	commas were found. 1 otherwise */
int no_consecutive_commas(char* input)
{
    int length = strlen(input);
    int i;
    for (i = 0; i < length; i++)
    {
    	if (input[i] == ',' && input[i+1] == ',')
    		return 0;
    }
    return 1; /* No consecutive commas were found */	
}


/* Narrows big spaces to one single space - part of the function 
	no_missing_commas */
void narrow_spaces(char* input)
{
    int length = strlen(input);
    int i, j, space_counter = 0;
    
    /* counts how many spaces in a row */
    for (i = 0, j = 0; i < length; i++)
    {
        if (input[i] == ' ')  /* found space */
            space_counter++;
        else 
            space_counter = 0; 
        
        /* copies only the first found space or the letter that was found */
        if (space_counter <= 1) 
        {
            input[j] = input[i];
            j++;
        }
    }
    input[j] = '\0'; 
}


/* Checks that there are no missing commas - between every parameter should be 
	at least one comma, return 0 if there is at least one missing comma */
int no_missing_commas(char* input)
{
	int length; 
    	int i;
    	narrow_spaces(input); /* narrows big spaces to a single space */
	length = strlen(input);

    	for (i = 1; i < length; i++)
    	{	
    		/* found 2 parameters not separated by a comma */
        		if (input[i] == ' ' && !(input[i+1] == ','  || \
        					 input[i - 1] == ','))
        			return 0; /* Missing comma found */
	}
	return 1;
}

	
/* Removes all spaces from the input (leading spaces, trailing spaces and 
	spaces within the input */
void remove_all_spaces(char* input)
{
	int length = strlen(input);
    	int i, j;
    	/* Skips leading spaces */
    	while (isspace((unsigned char)input[0]))
    	{
    		input++;
		length--;
	}
	/* Removes trailing spaces and spaces within the input */
    	for (i = 0, j = 0; i < length; i++)
    	{
        		if (!isspace((unsigned char)input[i])) 
        		{
            		input[j] = input[i];
           		j++;
         	}
    	}
    	input[j] = '\0'; /* fix the input (as a legal string */
}


/* Removes the function which is the first word from the input */
void remove_function(char* input)
{
    char* space_or_comma = strpbrk(input, " ,");
    if (space_or_comma != NULL)
    {
        memmove(input, space_or_comma, strlen(space_or_comma) + 1);
    }
}


/* Gets the input and checks if the first word which is the chosen function 
	exists and valid, returns 0 if the action isn't valid, 1 otherwise  */
int is_valid_function(char* input, char function[MAX_LENGTH]) 
{	
	int length = strcspn(input, " ,");  /* function's length */	
	remove_leading_trailing_spaces(input);
         /* copies the characters until " "/", " to "function". */
         strncpy(function, input, length);  
   	function[length] = '\0';  
   
	/* checks if the function is one of the legal functions */
	if (input_equals_function(function) == 1)
		return 1; 
         return 0;
}       


/* Checks for the current function if the parameters are of the correct type.
	 If so, activates the function */
void check_and_operate(char *function, char* parameters[], \
						Complex complex_list[])
{
	/* function with 3 parameters */
	if (strcmp(function, "read_comp") == 0) 
	{ 
		operate_read(function, parameters, complex_list);
	}
	/* functions with one parameter - complex number */	
	else if (strcmp(function,"print_comp") == 0 || 
					strcmp(function, "abs_comp") == 0) 
		 operate_one_complex(function, parameters, complex_list); 
	/* functions with two parameters - two complex numbers */		
	else if (strcmp(function,"add_comp") == 0 || 
		strcmp(function, "sub_comp") == 0 || 
		strcmp(function, "mult_comp_comp") == 0)
		{
		operate_two_complex(function, parameters, complex_list); 
	         }
		
	/* functions with two parameters - int and complex number */		
	else  /* function == "mult_comp_real" || function == "mult_comp_img")*/
		operate_complex_float(function, parameters, complex_list);
}


/* Checks if the typed variable is a complex number - the complex numbers 
	that are defined: A, B, C, D, E, F. otherwise, return 0 */
int is_complex_variable(char* parameter)
{
	if (strcmp(parameter, "A") == 0 || strcmp(parameter, "B") == 0 || 
	strcmp(parameter, "C") == 0 || strcmp(parameter, "D") == 0 || 
	strcmp(parameter, "E") == 0 || strcmp(parameter, "F") == 0)
		return 1;
	return 0;
}


/* Returns the match complex variable, depends on the name in token*/
Complex* recognize_complex_var(char* parameter, Complex complex_list[])
{
	if (strcmp(parameter, "A") == 0) 
		return &complex_list[0];
	if (strcmp(parameter, "B") == 0) 
		return &complex_list[1];
	if (strcmp(parameter, "C") == 0) 
		return &complex_list[2];
	if (strcmp(parameter, "D") == 0) 
		return &complex_list[3];
	if (strcmp(parameter, "E") == 0) 
		return &complex_list[4];
	return &complex_list[5];
}


/* Checks if the typed parameters match read_comp parameters - complex and 2 
	floats. If there is a match, read_comp function is activated */
void operate_read(char *function, char* parameters[], Complex complex_list[])
{
	Complex* var;
	Complex var_value;
	float real1, real2;
	char* first_param = parameters[0];
	char* second_param = parameters[1];
	char* third_param = parameters[2]; 
	/* checks if the first parameter is a complex variable */
	if (is_complex_variable(first_param) == 1)
		var = recognize_complex_var(first_param, complex_list);
	else 
	{
	        printf("Error - Undefined complex variable, %s\n",first_param);
	        return;
	}
	
	/* checks if the second paramter is a float */
	if (sscanf(second_param, "%f", &real1) != 1)
	{
		printf("Error - The second parameter should be float\n");
		return;
	}
	
	/* checks if the third paramter is a float */
	if (sscanf(third_param, "%f", &real2) != 1)
	{
		printf("Error - The third parameter should be float\n");
		return;
	}
	

	/* Parameters are correct, function is ready to go */
	read_comp(var, real1, real2); /* activates the function */
	printf("The current complex number is ");
	var_value = *var;
	print_comp(var_value); /* prints the result */
}

	
/* Checks if the received parameter is of complex type. If there is 
	a match, activates the requested function that gets 1 complex */
void operate_one_complex(char *function, char* parameters[], \
						Complex complex_list[])
{
	Complex* var;
	Complex var_value;
	float result;
	char* first_param = parameters[0];

	/* checks if the first parameter is a complex variable */
	if (is_complex_variable(first_param) == 1)
		var = recognize_complex_var(first_param, complex_list);
	else 
	{
	        printf("Error - Undefined complex variable, %s\n",first_param);
	        return;
	}
	
	/* Parameter is correct, the functions are ready to go */
	var_value = *var;
	if (strcmp(function, "print_comp") == 0)
	{
		printf("The current complex number is ");
		print_comp(var_value); /* activates the function */
		return;
	}
	if (strcmp(function, "abs_comp") == 0)
	{
		result = abs_comp(var_value); /* activates the function */
		printf("The absolute value is %f\n", result);
		return;
	}
}


/* Checks if the two received parameters are of complex type. If there is 
	a match, activates the requested function that gets 2 complex */
void operate_two_complex(char *function, char* parameters[], \
						Complex complex_list[])
{	
	Complex* var1;
	Complex* var2;
	Complex var_value1, var_value2, result; 
	char* first_param = parameters[0];
	char* second_param = parameters[1];
	
	/* checks if the first parameter is a complex variable */
	if (is_complex_variable(first_param) == 1)
		var1 = recognize_complex_var(first_param, complex_list);
	else 
	{
	        printf("Error - Undefined complex variable, %s\n",first_param);
	        return;
	}
	
	/* checks if the second paramter is a complex variable  */
	if (is_complex_variable(second_param) == 1)
		var2 = recognize_complex_var(second_param, complex_list);
	else 
	{
	       printf("Error - Undefined complex variable, %s\n",second_param);
	       return;
	}

	var_value1 = *var1;	
	var_value2 = *var2;
	/* Parameters are correct, the functions are ready to go */		
	
	if (strcmp(function, "add_comp") == 0)
		result  = add_comp(var_value1, var_value2); 
	if (strcmp(function,"sub_comp") == 0)
		result = sub_comp(var_value1, var_value2); 
	if (strcmp(function, "mult_comp_comp") == 0)
		result = mult_comp_comp(var_value1, var_value2); 			
	printf("The calculation result is: "); 
	print_comp(result); /* prints result */
	return;  
} 
	
	
/* Checks if the two received parameters are of complex type and float. If 
	there is a match, activates the requested function that gets a complex
	and a float */
void operate_complex_float(char *function, char* parameters[], \
						Complex complex_list[])
{
	float num; 
	Complex* var;
	Complex var_value, result;
	char* first_param = parameters[0];
	char* second_param = parameters[1];
	
	/* checks if the first parameter is a complex variable */
	if (is_complex_variable(first_param) == 1)
		var = recognize_complex_var(first_param, complex_list);
	else 
	{
	        printf("Error - Undefined complex variable, %s\n",first_param);
	        return;
	}
	
	/* checks if the second paramter is a float */
	if (sscanf(second_param, "%f", &num) != 1)
	{
		printf("Error - The second parameter should be float\n");
		return;
	}
	
	/* Parameters are correct, the functions are ready to go */
	var_value = *var;
	if (strcmp(function,"mult_comp_real") == 0)
		result = mult_comp_real(var_value, num); /* activates func */
	if (strcmp(function, "mult_comp_img") == 0)
		result = mult_comp_img(var_value, num); /* activates func */		
			
	printf("The calculation result is: ");
	print_comp(result); /* prints result */
	return;
}

		
int main(void)
{	
	Complex A, B, C, D, E, F; /* complex variable */
	Complex complex_list[COMPLEX_VAR]; /* = {A, B, C, D, E, F}; */
	char* parameters[PARAMETERS]; /* all parameters from user */
	char input[MAX_LENGTH + 1];
	char function[MAX_LENGTH];  /* requested action by user */
	int c;
	
	/* Initializes complex variables */
	read_comp(&A, 0, 0); read_comp(&B, 0, 0); read_comp(&C, 0, 0);
	read_comp(&D, 0, 0); read_comp(&E, 0, 0); read_comp(&F, 0, 0);
	/* Initializes complex_list */
	complex_list[0] = A;
    	complex_list[1] = B;
    	complex_list[2] = C;
    	complex_list[3] = D;
    	complex_list[4] = E;
    	complex_list[5] = F;
	/* message for user - welcome and show available functions */
	message_for_user();
	/* get user input, print the command the user typed */
	while (fgets(input, sizeof(input), stdin) != NULL)
	{
		if (strlen(input) == MAX_LENGTH)
		{
			int extra_char = getchar();
                  	if (extra_char != '\n' && extra_char != EOF)
             			printf("Error - The command is too big.\n");
             		while ((c = getchar()) != '\n');
             			continue;
                  } 
		
			
		if (strcmp(input, "\n") == 0) /* Empty line - skip */
			continue;
		printf("\n\n");
		printf("The command you chose to operate is:\n%s\n", input);
		
		/* check input */
		/* checks function's name, correct command structure, and
		 correct amount of parameters based on the chosen function */
		if (is_input_valid(input, function, parameters) == 1)
		{
		     	remove_all_spaces(function);
			if (strcmp(function, "stop") == 0) /* end program */	
			{
			        printf("\nThe program ended successfully\n"); 			
			        return 0;
			}
		         /* checks types of the parameters and operates the 
		      function if types are correct. otherwise prints error */
		        check_and_operate(function, parameters, complex_list);
		        printf("\n_________________________________________");
		        printf("\n\n\n\n");
		        printf("Please insert a new command:\n");
		}
		else
		{
			printf("\n_________________________________________");
			printf("\n\n\n\n");
			strcpy(input, "");
			printf("Please insert a new command:\n");
			continue;
		}
	}
	
	if (strcmp(function, "stop") != 0)
	       printf("Error - The program didn't stop with 'stop' command\n");
	return 0;
}
		 
