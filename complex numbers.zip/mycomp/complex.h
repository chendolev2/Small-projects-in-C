
/* Includes the typedef of a complex variable & prototypes of complex.c file */

/* Defines a complex number */
typedef struct {
	float real; /* real part */
	float imag; /* imaginary part */
} Complex;


/* Function prototypes of complex.c file */

/* Updates values of a complex variable */
void read_comp(Complex*, float, float); 
/* Prints the value of a complex variable */
void print_comp(Complex);
/* Adds two complex numbers */
Complex add_comp(Complex, Complex);
/* Subtracts the second complex number from the first */	
Complex sub_comp(Complex, Complex);
/* Multiplies a complex number with a real number */
Complex mult_comp_real(Complex, float);
/* Multiplies a complex number with an imaginary number */
Complex mult_comp_img(Complex, float);
/* Multiplies a complex number with another complex number  */
Complex mult_comp_comp(Complex, Complex);
/* Calculates and returns the absolute value of a complex number */
float abs_comp(Complex);
/* Stops the porgram */


