/* Includes constants and prototypes of mycomp.c file */

#define MAX_LENGTH 100 /* Max length of one row */
#define COMPLEX_VAR 6 /* How many complex variables in the program */
#define PARAMETERS 3 /* Maximum parameters from user */
/* Define - functions and several parameters in each: */
#define READ_COMP 3
#define PRINT_COMP 1
#define ADD_COMP 2
#define SUB_COMP 2
#define MULT_COMP_REAL 2
#define MULT_COMP_IMG 2
#define MULT_COMP_COMP 2
#define ABS_COMP 1
#define STOP 0


/* Welcome message, showing options to operate with examples */
void message_for_user(void); 
 /* Checks if the function the user typed is legal and can be operated */
int is_input_valid(char*, char*, char*[]);
/* Checks if the chosen function exists and valid */
int is_valid_function(char*, char*);
/* Removes the function from the input */
void remove_function(char*);
/* Checks that there are no missing commas */
int no_missing_commas(char*);
/* Removes all spaces from the input */
void remove_all_spaces(char*);
/* Narrows big spaces to one single space */
void narrow_spaces(char*);
/* Checks that there are no two consecutive commas */
int no_consecutive_commas(char*);
/* Checks if numbers of parameters typed by user, matches the current function*/
int parameters_num_correct(char*, char**, char*);
/* Compares the numbers - parameters user typed and the function's parameters */
int num_parmeters_match(char*, int);
/* Checks if the parameters are of the correct type and activates the function*/
void check_and_operate(char*, char*[], Complex* complex_list);
/* Checks if the typed variable is a complex number */
int is_complex_variable(char*);
/* Checks if the given parameters are complex, 2 floats. activates read_comp */  
void operate_read(char*, char*[], Complex[]);
/* Checks if the received parameter is complex type.activates the function */
void operate_one_complex(char*, char*[], Complex[]);
/* Checks if the received parameters are complex type. activates the function */
void operate_two_complex(char*, char*[], Complex[]);
/* Checks if the received parameters are complex and float. activates function*/
void operate_complex_float(char*, char*[], Complex[]);
/* Returns the match complex variable, depends on the name in token*/
Complex* recognize_complex_var(char*, Complex[]);
/* Checks if the current input is a single word */
int is_single_word(char*);
/* Checks if the input equals one of the legal functions */
int input_equals_function(char*);

/* checks if the last character in the input is a digit, letter or space  */	
int last_char_alpha_float_space(char*);
/* removes leading and trailing spaces in user's input */
void remove_leading_trailing_spaces(char*);

