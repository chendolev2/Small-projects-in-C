#include <stdio.h>
#include <math.h>
#include "complex.h"


/* This file includes operations on complex numbers such as: placing, printing,
	 adding, subtracting and multiplying by various factors */




/* Updates the current complex variable with new values that are passed as
	 parameters - new value for the real part and the imaginary part */
void read_comp(Complex* var, float new_real, float new_imag) 
{
	var-> real = new_real;
	var-> imag = new_imag;
}


/* Prints the value of the complex number, given as parameter */
void print_comp(Complex var)
{	/* absolute value of the imaginary part */
	float abs_imag = var.imag >= 0 ? var.imag : var.imag * (-1);
	if (var.real == -0)  /* not traditional */
		var.real = 0;
	printf("%0.2f %s (%0.2f)i\n",
	       var.real, var.imag >= 0 ? "+" : "-", abs_imag);
}


/* Adds 2 complex numbers that are given as parameters, returns the result */
Complex add_comp(Complex var1, Complex var2)
{
	Complex result;  /* add result */
	result.real = var1.real + var2.real;  /* sums the real part */
	result.imag = var1.imag + var2.imag;  /* sums the imaginary part */
	return result;
}


/* Subtracts the second complex number from the first, returns the result */	
Complex sub_comp(Complex var1, Complex var2)
{
	Complex result;  /* sum result */
	result.real = var1.real - var2.real;  /* real part */
	result.imag = var1.imag - var2.imag;  /* imaginary part */
	return result;
}


/* Multiplies a complex number with a real number that are given as parameters,
	returns the result */
Complex mult_comp_real(Complex var, float real)
{
	Complex result;  /* multiplication result */
	result.real = real * var.real;  /* real part */
	result.imag = real * var.imag;  /* imaginary part */
	return result;
}


/* Multiplies a complex number with an imaginary number that are given as
 	parameters, returns the result */
Complex mult_comp_img(Complex var, float imag)
{
	Complex result;  /* multiplication result */
	result.real = (-1) * imag * var.imag;  /* real part */
	result.imag = imag * var.real;  /* imaginary part */
	return result;
}


/* Multiplies a complex number with another complex number that are given as
 	parameters, returns the result */
Complex mult_comp_comp(Complex var1, Complex var2)	
{
	Complex result;  /* multiplication result */
	/* calculates the real part and the imaginary part */
	result.real = var1.real * var2.real - var1.imag * var2.imag; 
	result.imag = var1.real * var2.imag + var1.imag * var2.real;
	return result;
}


/* Calculates and returns the absolute value of a complex number, given as a 
	parameter */
float abs_comp(Complex var)
{
	return sqrt(var.real * var.real + var.imag * var.imag);	
}


